from pydantic import BaseModel
from typing import List, Optional

class SourceChunk(BaseModel):
    doc_name: str
    chunk_id: int
    text: str
    score: float

class AskRequest(BaseModel):
    query: str
    history: Optional[List[str]] = []

class AskResponse(BaseModel):
    answer: str
    sources: List[SourceChunk]

class UploadResponse(BaseModel):
    message: str
    doc_name: str
    num_chunks: int
