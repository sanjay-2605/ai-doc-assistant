import os
from pathlib import Path
from typing import List
from pypdf import PdfReader

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploaded_docs"
VECTOR_STORE_DIR = DATA_DIR / "vector_store"

for d in [DATA_DIR, UPLOAD_DIR, VECTOR_STORE_DIR]:
    os.makedirs(d, exist_ok=True)

def load_pdf_to_text(file_path: str) -> str:
    reader = PdfReader(file_path)
    texts = []
    for page in reader.pages:
        text = page.extract_text() or ""
        texts.append(text)
    return "\n".join(texts)

def chunk_text(text: str, chunk_size: int = 500, chunk_overlap: int = 100) -> List[str]:
    text = text.replace("\n", " ").strip()
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start += chunk_size - chunk_overlap
    return chunks
